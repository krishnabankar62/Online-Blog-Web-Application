package mypack;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;


public class InsertMe extends HttpServlet {

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
response.setDateHeader("Expires", 0); // Proxies.

response.setContentType("text/html");
PrintWriter pw = response.getWriter();

    //HttpSession hs = request.getSession();
        
    
    String uid = request.getParameter("uid");
    String passwd = request.getParameter("passwd");
    String email = request.getParameter("email");
    String mono = request.getParameter("mono");
    
    
    
    
    
    /*
    pw.println("uid : "+uid+"<br>");
    pw.println("passwd : "+passwd+"<br>");
    pw.println("email : "+email+"<br>");
    pw.println("mono : "+mono+"<br>");
    */

try{
    
    Class.forName("com.mysql.jdbc.Driver");  
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myblog", "root", "");
    String sql = "insert into signup values(?,?,?,?)";
    PreparedStatement st = con.prepareStatement(sql);
    
    /*
    pw.println("uid : "+uid+"<br>");
    pw.println("passwd : "+passwd+"<br>");
    pw.println("email : "+email+"<br>");
    pw.println("mono : "+mono+"<br>");
    */
    
    st.setString(1, uid);
    st.setString(2, passwd);
    st.setString(3, email);
    st.setString(4, mono);
    
    int count = st.executeUpdate();
    
    
   
  if(count>0)
  {
      pw.println("<b>successfuly Profile Created !<b>");
      RequestDispatcher rd = request.getRequestDispatcher("logInForm.html");
      rd.include(request, response);
  }
        
  else
  {
      pw.print("<font color=red> Profile Not Created !</font>");
      RequestDispatcher rd = request.getRequestDispatcher("signUpForm.html");
      rd.include(request, response);
  }
  
    
  con.close();
  st.close();
  
    
  
}
catch(Exception e){pw.println(e);}
 
   }
}
