package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MyBlogServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
        response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
        response.setDateHeader("Expires", 0); // Proxies.
        
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        
        HttpSession hs = request.getSession(false);
        String uid;
        String email;
        
        if(hs==null)
        {
           pw.println("<font color=red>U need to login first</font>");
           RequestDispatcher rd = request.getRequestDispatcher("logInForm.html");
           rd.include(request, response);
        }
        else
        {        
            uid = (String)hs.getAttribute("uid");
            email = (String)hs.getAttribute("email");
            
            
            
            
            try  {
            pw.println("<!DOCTYPE html>");
            pw.println("<html>");
            pw.println("<head>\n" +
"\n" +
"    <meta charset=\"utf-8\">\n" +
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n" +
"    <meta name=\"description\" content=\"\">\n" +
"    <meta name=\"author\" content=\"\">\n" +
"\n" +
"    <title>Blog</title>\n" +
"\n" +
"    <!-- Bootstrap core CSS -->\n" +
"    <link href=\"vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">\n" +
"\n" +
"    <!-- Custom fonts for this template -->\n" +
"    <link href=\"vendor/fontawesome-free/css/all.min.css\" rel=\"stylesheet\" type=\"text/css\">\n" +
"    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>\n" +
"    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>\n" +
"\n" +
"    <!-- Custom styles for this template -->\n" +
"    <link href=\"css/clean-blog.min.css\" rel=\"stylesheet\">\n" +
"\n" +
"  </head>");
    
            
            pw.println("<body style=\"text-align:center; background-color:#cfd9df\">");
            pw.println("<br><br><h1><b>WELCOME : "+uid+"</b></h1>");pw.println("<b><a style=\"margin:90%\" href=LogOutServlet> Logout </a></b><br><br>");
            
            pw.println("<!-- Page Header -->\n" +
"    <header class=\"masthead\" style=\"background-image: url('img/home-bg.jpg')\">\n" +
"      <div class=\"overlay\"></div>\n" +
"      <div class=\"container\">\n" +
"        <div class=\"row\">\n" +
"          <div class=\"col-lg-8 col-md-10 mx-auto\">\n" +
"            <div class=\"site-heading\">\n" +
"              <h1>WELCOME TO OUR BLOG</h1>\n" +
"              <span class=\"subheading\">Most recent post...</span>\n" +
"            </div>\n" +
"          </div>\n" +
"        </div>\n" +
"      </div>\n" +
"    </header>");
            
            pw.println("<form action=\"MyBlogServlet\" method=\"post\">");
            //pw.println("<h5>you can write here... " + request.getContextPath() + "</h5>");
            pw.println("<textarea rows=\"4\" cols=\"50\" name=\"ttext\" placeholder=\"you can write here...\"></textarea>");
            pw.println("<button type=\"submit\">Post</button>");
            pw.println("</form>");
            pw.println("</body>");
            pw.println("</html>");
        }catch(Exception e)
        {
            pw.print(e);
        }
            
            
            
            String ttext = (String)request.getParameter("ttext");
            
            
            
            //import Java.io.flush();
            try{
    
                
                Class.forName("com.mysql.jdbc.Driver");  
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myblog", "root", "");
                
                if(ttext!=null)
                {   
                    String sql = "insert into blog(ttext,uid,email) values(?,?,?)";
                    PreparedStatement st = con.prepareStatement(sql);
                    
                    st.setString(1, ttext);
                    st.setString(2, uid);
                    st.setString(3, email);
    
                    st.executeUpdate();
                
    //con.close();
                    st.close();
                }
    //Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/myblog", "root", "");
                
                PreparedStatement st2 = con.prepareStatement("select ttext, uid, email from blog order by sno desc;");
                
    
                ResultSet rs = st2.executeQuery();
                
                while(rs.next())
                {
                    String ttext2 = rs.getString("ttext");
                    String UserId = rs.getString("uid");
                    String UserEmail = rs.getString("email");
        
        
        //if(UserId.equals(uid)&& UserEmail.equals(email))
        //if(ttext2!=null)
        //{
                        pw.println("UserName : <i>"+UserId+"</i><br>");
                        pw.println("Email : <i>"+UserEmail+"</i><br>");
                        pw.println("Blog : "+ttext2+"<br><br>");
            //RequestDispatcher rd = request.getRequestDispatcher("MyBlogServlet");
            //rd.include(request, response);
    
       // }
                }
    
                con.close();
                st2.close();
    
                }catch(Exception e2)
                {
                    pw.println(e2);
                }

            
            pw.println("<!-- Footer -->\n" +
"    <footer>\n" +
"      <div class=\"container\">\n" +
"        <div class=\"row\">\n" +
"          <div class=\"col-lg-8 col-md-10 mx-auto\">\n" +
"            <ul class=\"list-inline text-center\">\n" +
"              <li class=\"list-inline-item\">\n" +
"                <a href=\"https://twitter.com\">\n" +
"                  <span class=\"fa-stack fa-lg\">\n" +
"                    <i class=\"fas fa-circle fa-stack-2x\"></i>\n" +
"                    <i class=\"fab fa-twitter fa-stack-1x fa-inverse\"></i>\n" +
"                  </span>\n" +
"                </a>\n" +
"              </li>\n" +
"              <li class=\"list-inline-item\">\n" +
"                <a href=\"https://www.facebook.com\">\n" +
"                  <span class=\"fa-stack fa-lg\">\n" +
"                    <i class=\"fas fa-circle fa-stack-2x\"></i>\n" +
"                    <i class=\"fab fa-facebook-f fa-stack-1x fa-inverse\"></i>\n" +
"                  </span>\n" +
"                </a>\n" +
"              </li>\n" +
"              <li class=\"list-inline-item\">\n" +
"                <a href=\"https://github.com\">\n" +
"                  <span class=\"fa-stack fa-lg\">\n" +
"                    <i class=\"fas fa-circle fa-stack-2x\"></i>\n" +
"                    <i class=\"fab fa-github fa-stack-1x fa-inverse\"></i>\n" +
"                  </span>\n" +
"                </a>\n" +
"              </li>\n" +
"            </ul>\n" +
"            <p class=\"copyright text-muted\">Copyright &copy; Your Website 2018</p>\n" +
"          </div>\n" +
"        </div>\n" +
"      </div>\n" +
"    </footer>\n" +
"\n" +
"    <!-- Bootstrap core JavaScript -->\n" +
"    <script src=\"vendor/jquery/jquery.min.js\"></script>\n" +
"    <script src=\"vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>\n" +
"\n" +
"    <!-- Custom scripts for this template -->\n" +
"    <script src=\"js/clean-blog.min.js\"></script>\n" +
"");
            
        }
    }
}
